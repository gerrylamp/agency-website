import React from 'react';
import { CodeIcon, PaintbrushIcon, LineChartIcon, SearchIcon, GlobeIcon, ZapIcon } from 'lucide-react';
const services = [{
  icon: <CodeIcon size={40} className="text-indigo-600" />,
  title: 'Web Development',
  description: 'Custom websites and web applications built with modern technologies for optimal performance.'
}, {
  icon: <PaintbrushIcon size={40} className="text-indigo-600" />,
  title: 'UI/UX Design',
  description: 'User-centered design that creates intuitive, engaging experiences that delight your customers.'
}, {
  icon: <LineChartIcon size={40} className="text-indigo-600" />,
  title: 'Digital Marketing',
  description: 'Data-driven marketing strategies that increase visibility and drive qualified traffic.'
}, {
  icon: <SearchIcon size={40} className="text-indigo-600" />,
  title: 'SEO Optimization',
  description: 'Improve your search rankings and increase organic traffic with our proven SEO techniques.'
}, {
  icon: <GlobeIcon size={40} className="text-indigo-600" />,
  title: 'Content Strategy',
  description: 'Strategic content creation that engages your audience and supports your business goals.'
}, {
  icon: <ZapIcon size={40} className="text-indigo-600" />,
  title: 'Brand Identity',
  description: "Distinctive visual identities that communicate your brand's unique value and personality."
}];
export function Services() {
  return <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We offer comprehensive digital solutions to help your business grow
            and succeed in the digital landscape.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => <div key={index} className="bg-gray-50 p-8 rounded-lg transition-all duration-300 hover:shadow-lg hover:transform hover:-translate-y-1">
              <div className="mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-600">{service.description}</p>
            </div>)}
        </div>
      </div>
    </section>;
}